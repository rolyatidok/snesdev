﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CharactorLib.Common;
using CharactorLib.Format;
using System.Drawing;

namespace TestPlugin
{
	/// <summary>
	/// 2bpp NES
	/// </summary>
	public class TestFormat : FormatBase
	{
		
		/// <summary>
		/// Constructor.
		/// </summary>
		public TestFormat()
		{
			base.FormatText = "[8][8]";
			base.Name = "TestFormat";
			base.Extension = "test";
			base.Author = "Yy";
			base.Url = "http://test.jp/index.html";
			// Flags
			base.Readonly = false;
			base.IsCompressed = false;
			base.EnableAdf = true;
			base.IsSupportMirror = false;
			base.IsSupportRotate = false;
			// Settings
			base.ColorBit = 2;
			base.ColorNum = 4;
			base.CharWidth = 8;
			base.CharHeight = 8;
			// Settings for Image Convert
			base.Width = 128;
			base.Height = 128;

		}

		/// <summary>
		/// データのアドレスを取得する。
		/// ex)NESならヘッダを読む。
		/// </summary>
		/// <param name="mData">全データ</param>
		/// <returns>アドレス</returns>
		public override int GetDataAddress(byte[] data)
		{
			int addr = 0;
			if ((data != null) && (data.Length > 0x10))
			{
				// NESヘッダを読む
				try
				{
					NesHeader header = new NesHeader(data);
					if (header.IsNesHeader)
					{
						byte prg = header.PrgRom;
						byte chr = header.ChrRom;
						if (chr > 0)
						{
							// CHR在りの場合、PRGのサイズ以降がCHRのアドレス
							addr = prg * 0x4000;
						}
						else
						{
							// CHR無しの場合
							addr = 0;
						}
						// トレイナー対応
						if (header.IsTrainer)
						{
							addr += 0x0200;
						}
						// NESヘッダアドレスを加算
						addr += 0x10;
					}
				}
				catch
				{
				}
			}
			return addr;
		}

		/// <summary>
		/// Charactor Convert.
		/// </summary>
		/// <param name="data">Data</param>
		/// <param name="addr">Data address</param>
		/// <param name="bytemap">Bytemap</param>
		/// <param name="px">Bytemap position X</param>
		/// <param name="py">Bytemap position Y</param>
		public override void ConvertMemToChr(Byte[] data, int addr, Bytemap bytemap, int px, int py)
		{
			// 8ライン展開
			for (int y = 0; y < CharHeight; y++)
			{
				int l0Addr = y + addr;
				int l1Addr = l0Addr + 0x08;
				byte l0 = data[l0Addr];
				byte l1 = data[l1Addr];
				// 8ドット展開
				for (int x = 0; x < CharWidth; x++)
				{
					byte v0 = (byte)((l0 >> (7 - x)) & 0x01);
					byte v1 = (byte)((l1 >> (7 - x)) & 0x01);
					byte value = (byte)((v1 << 1) | v0);
					Point p = base.GetAdvancePixelPoint(px + x, py + y);
					int bytemapAddr = bytemap.GetPointAddress(p.X, p.Y);
					bytemap.Data[bytemapAddr] = value;
				}
			}
		}

		/// <summary>
		/// Charactor Convert.
		/// </summary>
		/// <param name="data">Data</param>
		/// <param name="addr">Data address</param>
		/// <param name="bytemap">Bytemap</param>
		/// <param name="px">Bytemap position X</param>
		/// <param name="py">Bytemap position Y</param>
		public override void ConvertChrToMem(Byte[] data, int addr, Bytemap bytemap, int px, int py)
		{
			// 8ライン更新
			for (int y = 0; y < CharHeight; y++)
			{
				int l0Addr = y + addr;
				int l1Addr = l0Addr + 0x08;
				byte l0 = 0;
				byte l1 = 0;
				// 8ドット更新
				for (int x = 0; x < CharWidth; x++)
				{
					Point p = base.GetAdvancePixelPoint(px + x, py + y);
					int bytemapAddr = bytemap.GetPointAddress(p.X, p.Y);
					byte value = bytemap.Data[bytemapAddr];
					int p0 = (value >> 0) & 1;
					int p1 = (value >> 1) & 1;
					l0 |= (byte)(p0 << (7 - x));
					l1 |= (byte)(p1 << (7 - x));
				}
				data[l0Addr] = l0;
				data[l1Addr] = l1;
			}
		}


	}
}
